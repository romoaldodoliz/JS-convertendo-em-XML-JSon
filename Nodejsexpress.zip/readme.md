Exemplo de como usar Javascript para gerar ficheiro XML e ter resposta em JSON

@author: Romoaldo Edmundo Doliz

(Instale na tua maquina o pacote) Install package
```bash
npm install
```

Run app 
```bash
node index.js
```


Local: 
```
localhost:9000
```


Endpoint
```
GET localhost:9001/mahasiswa?type=xml
```

```
POST localhost:9001/mahasiswa/tambah?type=xml
```

Nao se esqueca de criar conexao.js para conectar-se a sua base de dados link abaixo com exemplo:

https://devafilth.wordpress.com/2017/12/08/configurando-o-node-js-com-o-banco-de-dados-oracle/

Boa sorte

Duvidas 
Romoaldodoliz@hotmail.com
+258 862020616
